import { createWorker } from 'tesseract.js';
import sharp from 'sharp';

let workerPromise = null;

async function getWorker() {
  if (!workerPromise) {
    workerPromise = createWorker(process.env.OCR_LANG || 'ind+eng');
  }
  return workerPromise;
}

const clean = (s = '') => s.replace(/\u0000/g, ' ').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
const oneLine = (s = '') => clean(s).replace(/\s*\n\s*/g, ' ').trim();

function normalizeOCRText(text) {
  return clean(text)
    .replace(/[|]/g, 'I')
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'");
}

async function recognize(img, psm = 6) {
  const worker = await getWorker();
  const r = await worker.recognize(img, { config: { tessedit_pageseg_mode: String(psm) } });
  return {
    text: normalizeOCRText(r?.data?.text || ''),
    confidence: Number(r?.data?.confidence || 0),
    words: r?.data?.words || []
  };
}

function best(results) {
  return [...results].sort((a, b) => b.confidence - a.confidence)[0] || { text: '', confidence: 0, words: [] };
}

function cleanField(value) {
  return oneLine(value)
    .replace(/^[:;\-–—]+/, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

function afterLabel(lines, labels, maxLines = 1) {
  const low = lines.map(x => x.toLowerCase());
  for (let i = 0; i < low.length; i++) {
    const line = low[i];
    const label = labels.find(x => line.includes(x));
    if (!label) continue;
    const original = lines[i];
    const pos = line.indexOf(label);
    const sameLine = cleanField(original.slice(pos + label.length).replace(/^\s*[:.-]\s*/, ''));
    if (sameLine && sameLine.length > 1) return sameLine;
    const parts = [];
    for (let j = i + 1; j < Math.min(lines.length, i + 1 + maxLines); j++) {
      const candidate = cleanField(lines[j]);
      if (!candidate || /^(shipper|consignee|address|alamat|contact|kontak|container|job|tanggal|date|place|term|goods|qty|quantity|volume|weight|berat)/i.test(candidate)) break;
      parts.push(candidate);
    }
    if (parts.length) return cleanField(parts.join(' '));
  }
  return '';
}

function firstMatch(text, patterns) {
  for (const p of patterns) {
    const m = text.match(p);
    if (m) return m[1] ?? m[0];
  }
  return '';
}

function normalizeContainer(s) {
  return cleanField(s).toUpperCase().replace(/[^A-Z0-9-]/g, '').replace(/([A-Z]{4})(\d{6})$/, '$1$2');
}

function parseDate(text) {
  const m = text.match(/\b(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})\b/);
  if (!m) return '';
  let y = m[3]; if (y.length === 2) y = '20' + y;
  const d = String(m[1]).padStart(2, '0'), mo = String(m[2]).padStart(2, '0');
  return `${y}-${mo}-${d}`;
}

function numberValue(s) {
  if (!s) return null;
  const normalized = String(s).replace(/\s/g, '').replace(/,(?=\d{1,2}(?:\D|$))/g, '.');
  const m = normalized.match(/-?\d+(?:\.\d+)?/);
  return m ? Number(m[0]) : null;
}

function parseDimensions(text) {
  const m = text.match(/(\d{1,5}(?:[.,]\d+)?)\s*[xX×*]\s*(\d{1,5}(?:[.,]\d+)?)\s*[xX×*]\s*(\d{1,5}(?:[.,]\d+)?)/);
  if (!m) return [null, null, null];
  return m.slice(1, 4).map(x => Number(x.replace(',', '.')));
}

function parseItems(text) {
  const lines = text.split(/\r?\n/).map(cleanField).filter(Boolean);
  let goods = afterLabel(lines, ['declare goods', 'description of goods', 'description', 'commodity', 'goods', 'jenis barang'], 2);
  if (!goods) {
    const idx = lines.findIndex(x => /declare\s+goods|description|commodity|goods|jenis barang/i.test(x));
    if (idx >= 0 && lines[idx + 1]) goods = lines[idx + 1];
  }

  const qtyText = firstMatch(text, [
    /(?:qty|quantity|jumlah)\s*[:\-]?\s*([\d.,]+)/i,
    /\b([\d.,]+)\s*(?:pcs|piece|pieces|carton|ctn|dus|box|bags|kg)\b/i
  ]);
  const packaging = firstMatch(text, [/(?:packaging|package|kemasan)\s*[:\-]?\s*([^\n]+)/i]);
  const dimText = firstMatch(text, [/(?:dimension|dimensi|size|ukuran)\s*[:\-]?\s*([^\n]+)/i, /(\d{1,5}\s*[xX×]\s*\d{1,5}\s*[xX×]\s*\d{1,5})/]);
  const [p, l, t] = parseDimensions(dimText);
  const volume = firstMatch(text, [/(?:volume|cbm|m3|m³)\s*[:\-]?\s*([\d.,]+)/i]);
  const weight = firstMatch(text, [/(?:weight|gross\s*weight|berat)\s*[:\-]?\s*([\d.,]+)/i]);

  return [{
    line_no: 1,
    declare_goods: cleanField(goods),
    qty: numberValue(qtyText),
    packaging: cleanField(packaging),
    dimension_p: p,
    dimension_l: l,
    dimension_t: t,
    volume_m3: numberValue(volume),
    weight_ton: numberValue(weight),
    remarks: ''
  }];
}

function parseFields(text) {
  const lines = text.split(/\r?\n/).map(cleanField).filter(Boolean);
  const full = lines.join('\n');
  const container = firstMatch(full, [
    /(?:container\s*(?:no|number)?|no\.?\s*container)\s*[:#\-]?\s*([A-Z]{3,4}\s*\d{5,8})/i,
    /\b([A-Z]{4}\s*\d{6,7})\b/i
  ]);
  const job = firstMatch(full, [/(?:job\s*(?:no|number)?|job)\s*[:#\-]?\s*([A-Z0-9./_-]{3,})/i]);
  const receipt = firstMatch(full, [/(?:cargo\s*receipt|receipt\s*(?:no|number)|no\.?\s*receipt)\s*[:#\-]?\s*([A-Z0-9./_-]{3,})/i]);
  const term = firstMatch(full, [/(?:term\s*of\s*shipment|shipment\s*term|term)\s*[:#\-]?\s*([^\n]+)/i]);

  const shipper = afterLabel(lines, ['shipper name', 'shipper', 'pengirim'], 1);
  const consignee = afterLabel(lines, ['consignee name', 'consignee', 'penerima'], 1);
  const shipperAddress = afterLabel(lines, ['shipper address', 'alamat shipper', 'alamat pengirim'], 2);
  const consigneeAddress = afterLabel(lines, ['consignee address', 'alamat consignee', 'alamat penerima'], 2);
  const shipperContact = afterLabel(lines, ['shipper contact', 'contact shipper', 'kontak shipper', 'telepon shipper'], 1);
  const consigneeContact = afterLabel(lines, ['consignee contact', 'contact consignee', 'kontak consignee', 'telepon consignee'], 1);
  const place = afterLabel(lines, ['place of receipt', 'place receipt', 'tempat penerimaan'], 1);
  const date = parseDate(firstMatch(full, [/(?:date|tanggal)\s*[:\-]?\s*([^\n]+)/i]) || full);

  return {
    receipt_no: cleanField(receipt),
    document_date: date,
    place_of_receipt: cleanField(place),
    container_no: normalizeContainer(container),
    job_no: cleanField(job),
    term_of_shipment: cleanField(term),
    shipper_name: cleanField(shipper),
    shipper_address: cleanField(shipperAddress),
    shipper_contact: cleanField(shipperContact),
    consignee_name: cleanField(consignee),
    consignee_address: cleanField(consigneeAddress),
    consignee_contact: cleanField(consigneeContact)
  };
}

async function preprocessVariants(buf) {
  const meta = await sharp(buf).metadata();
  const width = Math.min(Math.max(meta.width || 1600, 1600), 3200);
  const base = sharp(buf).rotate().resize({ width, withoutEnlargement: false }).flatten({ background: '#ffffff' });
  const normal = await base.clone().grayscale().normalize().sharpen({ sigma: 1 }).png().toBuffer();
  const contrast = await base.clone().grayscale().linear(1.25, -25).normalize().sharpen({ sigma: 1.2 }).png().toBuffer();
  const threshold = await base.clone().grayscale().normalize().threshold(175).png().toBuffer();
  return { normal, contrast, threshold };
}

export async function runTemplateOCR(buf) {
  const variants = await preprocessVariants(buf);
  const passes = [];
  for (const [name, image] of Object.entries(variants)) {
    for (const psm of [6, 11]) {
      const r = await recognize(image, psm);
      passes.push({ ...r, variant: name, psm });
    }
  }
  const winner = best(passes);
  const parsed = parseFields(winner.text);
  const items = parseItems(winner.text);

  // If the best full-page pass missed key fields, use a second pass from the best alternative.
  const alternatives = passes.filter(x => x !== winner).sort((a, b) => b.confidence - a.confidence);
  for (const alt of alternatives.slice(0, 3)) {
    const p = parseFields(alt.text);
    for (const k of Object.keys(parsed)) if (!parsed[k] && p[k]) parsed[k] = p[k];
    const ai = parseItems(alt.text)[0];
    const item = items[0];
    for (const k of Object.keys(item)) if ((item[k] === '' || item[k] == null) && ai[k] != null && ai[k] !== '') item[k] = ai[k];
  }

  // Confidence is deliberately conservative when the OCR text is too short.
  const chars = winner.text.replace(/\s/g, '').length;
  const completeness = [parsed.container_no, parsed.job_no, parsed.shipper_name, parsed.consignee_name].filter(Boolean).length / 4;
  const confidence = Math.max(0, Math.min(99.9, winner.confidence * 0.75 + completeness * 25 + Math.min(chars / 1000, 1) * 5));

  return {
    ocr_confidence: Number(confidence.toFixed(2)),
    raw_ocr_text: winner.text,
    fields: parsed,
    items,
    diagnostics: {
      language: process.env.OCR_LANG || 'ind+eng',
      winning_variant: winner.variant,
      winning_psm: winner.psm,
      passes: passes.map(x => ({ variant: x.variant, psm: x.psm, confidence: Number(x.confidence.toFixed(2)), characters: x.text.replace(/\s/g, '').length }))
    }
  };
}
