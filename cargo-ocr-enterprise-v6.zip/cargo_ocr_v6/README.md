# Cargo OCR Enterprise v6

Versi ini memperbaiki masalah **"OCR gagal: Failed to fetch"** saat `index.html` dibuka langsung dari Windows Explorer (`file:///C:/.../index.html`).

## Cara 1 — Docker (disarankan)

```bash
docker compose down
docker compose up --build
```

Buka:

`http://localhost:8080`

## Cara 2 — Buka index.html langsung

Jika Anda membuka:

`C:\Users\saiful\Downloads\index.html`

frontend otomatis memakai API:

`http://localhost:3000`

Jadi tidak lagi mencoba `file:///api/ocr` yang menyebabkan **Failed to fetch**.

Tetap pastikan backend Docker berjalan dan port 3000 terbuka.

## Tes backend

Buka di browser:

`http://localhost:3000/api/health`

Jika aktif, akan muncul JSON dengan `ok:true`.

## Alur

Foto/scan → `/api/ocr` → Tesseract `ind+eng` → parsing Cargo Receipt → form otomatis → review → `/api/documents` → PostgreSQL.
