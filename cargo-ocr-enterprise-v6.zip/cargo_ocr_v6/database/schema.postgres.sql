CREATE TABLE IF NOT EXISTS cargo_documents (
  id BIGSERIAL PRIMARY KEY,
  receipt_no VARCHAR(80),
  document_type VARCHAR(80) NOT NULL DEFAULT 'Cargo Receipt - LCL',
  document_date DATE,
  place_of_receipt VARCHAR(255),
  container_no VARCHAR(30),
  job_no VARCHAR(80),
  term_of_shipment VARCHAR(100),
  shipper_name VARCHAR(255),
  shipper_address TEXT,
  shipper_contact VARCHAR(120),
  consignee_name VARCHAR(255),
  consignee_address TEXT,
  consignee_contact VARCHAR(120),
  status VARCHAR(30) NOT NULL DEFAULT 'REVIEW',
  ocr_confidence NUMERIC(5,2),
  raw_ocr_text TEXT,
  source_filename VARCHAR(255),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS cargo_items (
  id BIGSERIAL PRIMARY KEY,
  document_id BIGINT NOT NULL REFERENCES cargo_documents(id) ON DELETE CASCADE,
  line_no INTEGER NOT NULL,
  declare_goods VARCHAR(255),
  qty NUMERIC(12,2),
  packaging VARCHAR(80),
  dimension_p NUMERIC(12,2),
  dimension_l NUMERIC(12,2),
  dimension_t NUMERIC(12,2),
  volume_m3 NUMERIC(12,4),
  weight_ton NUMERIC(12,4),
  remarks TEXT
);

CREATE INDEX IF NOT EXISTS idx_cargo_documents_container ON cargo_documents(container_no);
CREATE INDEX IF NOT EXISTS idx_cargo_documents_created ON cargo_documents(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_cargo_items_document ON cargo_items(document_id);
